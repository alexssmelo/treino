// Cole aqui a configuração do seu projeto Firebase (veja SETUP-NUVEM.md).
// Esses valores não são segredo: a segurança vem das regras do Firestore.
// Enquanto apiKey estiver vazio, o app funciona normalmente, só sem contas.
export const firebaseConfig = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
};
